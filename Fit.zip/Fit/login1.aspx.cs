﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class login1 : System.Web.UI.Page
{
     SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-03AQA86\SQLEXPRESS;Initial Catalog=Fit;Integrated Security=true");
    protected void Page_Load(object sender, EventArgs e)
    {
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string str = "select * from Candidates where username='" + TextBox1.Text + "' and password='" + TextBox2.Text + "'";
        SqlCommand cmd = new SqlCommand(str, con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        
        
        string str1 = "select * from Trainers where username='" + TextBox1.Text + "' and password='" + TextBox2.Text + "'";
            SqlCommand cmd1 = new SqlCommand(str1, con);
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            DataTable dt1 = new DataTable();
            da1.Fill(dt1);

        string str2 = "select * from admin where username='" + TextBox1.Text + "' and password='" + TextBox2.Text + "'";
        SqlCommand cmd2 = new SqlCommand(str2, con);
        SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
        DataTable dt2 = new DataTable();
        da2.Fill(dt2);

        if (dt.Rows.Count >= 1)
        {
            string role = dt.Rows[0]["utype"].ToString();


                Session["C_id"] = dt.Rows[0]["C_id"].ToString();
                Session["Name"] = dt.Rows[0]["Name"].ToString();
                Session["User"] = TextBox1.Text;
                Response.Redirect("User_Home.aspx");

            }

        else if (dt1.Rows.Count >= 1)
            {
                string role = dt1.Rows[0]["utype"].ToString();

                if (role == "trainer")
                {
                    Session["Name"] = dt1.Rows[0]["Name"].ToString();
                    Session["T_id"] = dt1.Rows[0]["T_id"].ToString();
                    Session["User"] = TextBox1.Text;
                    Response.Redirect("Trainer_Home.aspx");

                }
                
            }
            else if (dt2.Rows.Count >= 1)
            {
                string role = dt2.Rows[0]["utype"].ToString();

                if (role == "admin")
                {
                    Session["User"] = TextBox1.Text;
                    Response.Redirect("admin_Home.aspx");

                }
                
            }

            else
            {
                Response.Write("<script>alert('Invalid Username and   Password')</script>");
            }
        }
    }
