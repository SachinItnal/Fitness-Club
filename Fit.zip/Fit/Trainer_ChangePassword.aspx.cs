﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Trainer_ChangePassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-03AQA86\SQLEXPRESS;Initial Catalog=Fit;Integrated Security=true");
        string st = "select password from Trainers where password='" + TextBox1.Text + "'";
        SqlCommand cmd = new SqlCommand(st, con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count >= 1)
        {
            if (TextBox2.Text == TextBox3.Text)
            {
                string str = "Update Trainers set password='" + TextBox3.Text + "' where password='" + TextBox1.Text + "'";
                SqlCommand cmd1 = new SqlCommand(str, con);
                con.Open();
                cmd1.ExecuteNonQuery();
                con.Close();
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Password Update SuccessFully')", true);
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('New Password and Confirm Password Should be Same')", true);
            }
        }
        else
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Enter Correct Old Password')", true);
        }
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
    }
}