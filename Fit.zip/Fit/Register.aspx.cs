﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.IO;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Data;

public partial class Register : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-03AQA86\SQLEXPRESS;Initial Catalog=Fit;Integrated Security=true");
        //con.Open();
        //SqlCommand cmd = new SqlCommand("select * from Package", con);
        //SqlDataAdapter da = new SqlDataAdapter(cmd);
        //DataSet ds = new DataSet();
        //da.Fill(ds);
        //DropDownList1.DataTextField = "Package";
        //DropDownList1.DataValueField = "amt";
        //DropDownList1.DataSource = ds;
        //DropDownList1.DataBind();
        //DropDownList1.Items.Insert(0, new ListItem("-Select Trainer-", "0"));
        Image1.Visible = false;
        Label1.Visible = false;
        TextBox6.Visible = false;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string sdate = DateTime.Now.ToString();
        DateTime dat = DateTime.Now;
        string plan = DropDownList1.SelectedValue;
        int p = int.Parse(plan);
        int days = 30 * p;
        DateTime dt1 = dat.AddDays(days);

        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Registered SuccessFully')", true);
        string utype = "user";
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-03AQA86\SQLEXPRESS;Initial Catalog=Fit;Integrated Security=true");
        string gender = " ";
        if (RadioButton1.Checked)
        {
            gender = "Male";
        }
        else if (RadioButton2.Checked)
        {
            gender = "Female";
        }
        string str = "insert into Candidates values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + gender + "','" + TextBox5.Text + "','" + DropDownList1.SelectedItem + "','" + TextBox10.Text + "','" + sdate + "','" + dt1 + "','" + TextBox11.Text + "','" + TextBox12.Text + "','" + utype + "','"+TextBox6.Text+"')";
        SqlCommand cmd = new SqlCommand(str, con);
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();

        //Label1.Text = dt1.ToShortDateString();

        StringBuilder sb = new StringBuilder();
        sb.AppendLine("You Have Successfully Registered");
        sb.AppendLine(" Username is :" + TextBox11.Text);
        sb.AppendLine(" Password is :" + TextBox12.Text);
        sb.AppendLine(" Plan(In Month) is :" + DropDownList1.SelectedValue);
        sb.AppendLine(" Package is :" + TextBox10.Text);
        sb.AppendLine(" working days Starting From :" + sdate);
        sb.AppendLine(" working days Expires on :" + dt1);


        SmtpClient sc = new SmtpClient("smtp.gmail.com", 587);
        sc.EnableSsl = true;
        sc.DeliveryMethod = SmtpDeliveryMethod.Network;
        sc.UseDefaultCredentials = false;
        sc.Credentials = new NetworkCredential("sachinitnal8@gmail.com", "ykvrsbqwxftmgpuh");
        MailMessage msg = new MailMessage();
        msg.To.Add(TextBox3.Text);
        msg.From = new MailAddress("Fitness Club<sachinitnal8@gmail.com>");
        msg.Subject = "Fitness Club";
        msg.Body = sb.ToString();
        sc.Send(msg);

        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";
        TextBox12.Text = "";
        TextBox10.Text = "";
        TextBox6.Text = "";
        TextBox11.Text = "";
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-03AQA86\SQLEXPRESS;Initial Catalog=Fit;Integrated Security=true");

        string plan = DropDownList1.SelectedValue;
        con.Open();
        string st = "select * from Package where package='" + plan + "'";
        SqlCommand cm = new SqlCommand(st, con);
        SqlDataAdapter da = new SqlDataAdapter(cm);
        DataTable dt = new DataTable();
        da.Fill(dt);
        TextBox10.Text = dt.Rows[0]["amt"].ToString();
        con.Close();

        string sdate = DateTime.Now.ToString();
        DateTime dat = DateTime.Now;
        plan = DropDownList1.SelectedValue;
        int p = int.Parse(plan);
        int days = 0;
        if (p == 12)
            days = 365;
        else
            days = 30 * p;
        DateTime dt1 = dat.AddDays(days);
        //Label1.Text = dt1.ToShortDateString();
        //Response.Write("Hello");
        Label1.Visible = true;
        Image1.Visible = true;
        TextBox6.Visible = true;
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
    }
}