﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class User_Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-03AQA86\SQLEXPRESS;Initial Catalog=Fit;Integrated Security=true");
        //string str1 = "select T_id from Schedule where C_id='"+Session["C_id"]+"'";
        ////string str = "SELECT t.Name, t.Photo, s.Time_from, s.Time_to from Trainers AS t INNER JOIN Schedule AS s ON t.T_id=s.T_id";
        //SqlCommand cmd = new SqlCommand(str1, con);
        //SqlDataAdapter da = new SqlDataAdapter(cmd);
        //DataTable dt = new DataTable();
        //da.Fill(dt);
        //if (dt.Rows.Count >= 1)
        //{
        //    string tid = dt.Rows[0]["T_id"].ToString();
        //    string str2 = "select Name from Trainers where T_id='" + tid + "'";
        //    SqlCommand cmd1 = new SqlCommand(str2, con);
        //    SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
        //    DataTable dt1 = new DataTable();
        //    da1.Fill(dt1);
        //    if (dt.Rows.Count >= 1)
        //    {
        //        GridView2.DataSource = dt1;
        //        GridView2.DataBind();
        //    }
        //}
      
    }
    protected void GridView5_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DateTime Date = Convert.ToDateTime(e.Row.Cells[1].Text);
            e.Row.Cells[1].Text = Date.ToString("dd-MMMM-yyyy");
        }
    }
}