﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class User_Package : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-03AQA86\SQLEXPRESS;Initial Catalog=Fit;Integrated Security=true");
    protected void Page_Load(object sender, EventArgs e)
    {
        TextBox1.Text = Session["C_id"].ToString();
        Image1.Visible = false;
        Label5.Visible = false;
        TextBox4.Visible = false;

        //SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-03AQA86\SQLEXPRESS;Initial Catalog=Fit;Integrated Security=true");
        //string str1 = "select C_id from Schedule where C_id='" + Session["C_id"] + "'";
        //SqlCommand cmd = new SqlCommand(str1, con);
        //SqlDataAdapter da = new SqlDataAdapter(cmd);
        //DataTable dt = new DataTable();
        //da.Fill(dt);
        //if (dt.Rows.Count >= 1)
        //{
        //    string tid = dt.Rows[0]["C_id"].ToString();
        //    string str2 = "select Name from Candidates where C_id='" + tid + "'";
        //    SqlCommand cmd1 = new SqlCommand(str2, con);
        //    SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
        //    DataTable dt1 = new DataTable();
        //    da1.Fill(dt1);
        //    if (dt.Rows.Count >= 1)
        //    {
        //        TextBox2.Text = dt1.ToString();
        //    }
        //}

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

        string plan = DropDownList1.SelectedValue;
        con.Open();
        string st = "select * from Package where package='" + plan + "'";
        SqlCommand cm = new SqlCommand(st, con);
        SqlDataAdapter da = new SqlDataAdapter(cm);
        DataTable dt = new DataTable();
        da.Fill(dt);
        TextBox3.Text = dt.Rows[0]["amt"].ToString();
        con.Close();

        string sdate = DateTime.Now.ToString();
        DateTime dat = DateTime.Now;
        plan = DropDownList1.SelectedValue;
        int p = int.Parse(plan);
        int days = 0;
        if (p == 12)
            days = 365;
        else
            days = 30 * p;
        DateTime dt1 = dat.AddDays(days);
        Image1.Visible = true;
        Label5.Visible = true;
        TextBox4.Visible = true;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string sdate = DateTime.Now.ToString();
        string plan = DropDownList1.SelectedValue;
        DateTime dat = DateTime.Now;
        plan = DropDownList1.SelectedValue;
        int p = int.Parse(plan);
        int days = 0;
        if (p == 12)
            days = 365;
        else
            days = 30 * p;
        DateTime edate = dat.AddDays(days);

        string str = "insert into Can_Package values('" + TextBox1.Text + "','" + DropDownList1.SelectedItem + "','" + TextBox3.Text + "','"+sdate+"','"+edate+"','"+TextBox4.Text+"')"; 
        SqlCommand cmd = new SqlCommand(str, con);
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();

        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Data Saved SuccessFully')", true);

        TextBox1.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        Response.Redirect("User_Plan.aspx");
    }
}