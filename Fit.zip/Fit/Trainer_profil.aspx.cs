﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.IO;

public partial class Trainer_profil : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-03AQA86\SQLEXPRESS;Initial Catalog=Fit;Integrated Security=true");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            filldata();
    }
    private void filldata()
    {
        SqlDataAdapter da = new SqlDataAdapter("select * from Trainers", con);
        DataSet ds = new DataSet();
        da.Fill(ds);
        //DataList1.DataSource = da;
        //DataList1.DataBind();
    }
    protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
    {
        if (e.CommandName == "edit")
        {
            DataList1.EditItemIndex = e.Item.ItemIndex;
            filldata();
        }
        else if (e.CommandName == "cancel")
        {
            DataList1.EditItemIndex = 1;
            filldata();
            Response.Redirect("Trainer_profil.aspx");
        }
        else if (e.CommandName == "update")
        {
            //FileUpload FileUpload = (FileUpload)DataList1.Items[DataList1.EditItemIndex].FindControl("FileUpload");
            string link = "image/" + Path.GetFileName(((FileUpload)e.Item.FindControl("FileUpload1")).FileName);
            //string Photo = ((FileUpload)e.Item.FindControl("FileUpload1")).FileName;
            //string T_id = ((Label)e.Item.FindControl("Label1")).Text;
            string Name = ((TextBox)e.Item.FindControl("TextBox1")).Text;
            string Cantactnumber = ((TextBox)e.Item.FindControl("TextBox2")).Text;
            string EmailId = ((TextBox)e.Item.FindControl("TextBox3")).Text;
            string Address = ((TextBox)e.Item.FindControl("TextBox4")).Text;
            string Gender = ((TextBox)e.Item.FindControl("TextBox7")).Text;
            string DateOfBirth = ((TextBox)e.Item.FindControl("TextBox5")).Text;
            string Expreience = ((TextBox)e.Item.FindControl("TextBox6")).Text;
            //string Salary = ((TextBox)e.Item.FindControl("Label13")).Text;
            string username = ((TextBox)e.Item.FindControl("TextBox8")).Text;
            //string password = ((TextBox)e.Item.FindControl("Label14")).Text;
            SqlCommand cmd = new SqlCommand("update Trainers set Name='" + Name + "',Photo='" + link + "',ContactNumber='"+Cantactnumber+"',EmailID='"+EmailId+"',Address='"+Address+"',Gender='"+Gender+"',DateOfBirth='"+DateOfBirth+"',Experience='"+Expreience+"',username='"+username+"' where T_id='" + Session["T_id"] + "'", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            filldata();
            Response.Redirect("Trainer_profil.aspx");
        }
    }
}