﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-03AQA86\SQLEXPRESS;Initial Catalog=Fit;Integrated Security=true");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from Trainers", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            DropDownList1.DataTextField = "T_id";
            DropDownList1.DataValueField = "Name";
            DropDownList1.DataSource = ds;
            DropDownList1.DataBind();
            DropDownList1.Items.Insert(0, new ListItem("-Select Trainer-", "0"));
        }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        //string str = "select Name from Trainers where"+"T_id=@T_id";
        //SqlCommand cmd = new SqlCommand();
        //cmd.Parameters.AddWithValue("@T_id",DropDownList1.SelectedItem.Value);
        //cmd.CommandType = CommandType.Text;
        //cmd.CommandText = str;
        //cmd.Connection = con;
        //try
        //{
        //    con.Open();
        //    SqlDataAdapter sdr = cmd.ExecuteReader();
        //    while (sdr.Read())
        //    {
        //        TextBox1.Text = sdr[0].ToString();
        //    }
        //}
        //catch (Exception ex)
        //{
        //    throw ex;
        //}
        //finally
        //{
        //    con.Close();
        //    con.Dispose();
        //}
    }
}