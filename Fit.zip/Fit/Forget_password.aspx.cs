﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Net.Mail;
using System.Text;
using System.Net;
using System.Data;

public partial class Forget_password : System.Web.UI.Page
{
    //string email = Sendcode.to;
    string otp;
    SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-03AQA86\SQLEXPRESS;Initial Catalog=Fit;Integrated Security=true");
    protected void Page_Load(object sender, EventArgs e)
    {
        TextBox4.Visible = false;
        TextBox5.Visible = false;
        Label3.Visible = false;
        Label5.Visible = false;
        Button3.Visible = false;
    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        string st = "select * from Candidates where email='" + TextBox1.Text + "'";
        SqlCommand cmd = new SqlCommand(st, con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count >= 1)
        {
            string email = dt.Rows[0]["email"].ToString();
            Random rd = new Random();
            otp = (rd.Next(999999)).ToString();
            //TextBox2.Text = otp.ToString();

            Response.Cookies["otp"].Value = otp;
            Response.Cookies["otp"].Expires = DateTime.Now.AddMinutes(1);

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("OTP is :" + otp);

            SmtpClient sc = new SmtpClient("smtp.gmail.com", 587);
            sc.EnableSsl = true;
            sc.DeliveryMethod = SmtpDeliveryMethod.Network;
            sc.UseDefaultCredentials = false;
            sc.Credentials = new NetworkCredential("sachinitnal8@gmail.com", "ykvrsbqwxftmgpuh");
            MailMessage msg = new MailMessage();
            msg.To.Add(TextBox1.Text);
            msg.From = new MailAddress("Fitness Club<sachinitnal8@gmail.com>");
            msg.Subject = "Fitness Club";
            msg.Body = sb.ToString();
            sc.Send(msg);
            Label6.Text = "Send OTP Successfully";
        }
        else
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Invalid Email ID')", true);
        }
    }
    protected void Button2_Click1(object sender, EventArgs e)
    {
        HttpCookie ot = new HttpCookie("otp");
        ot = Request.Cookies["otp"];
        string otp1 = ot.Value;

        if (Request.Cookies["otp"] == null)
        {
            Label7.Text = "OTP Expired";

        }
        else if (otp1 == TextBox2.Text)
        {
            Label7.Text = "Successful Verify";
            TextBox4.Visible = true;
            TextBox5.Visible = true;
            Label3.Visible = true;
            Label5.Visible = true;
            Button3.Visible = true;
        }
        else
        {
            Label7.Text = "invalid OTP";
            TextBox4.Visible = false;
        }
    }
    protected void Button3_Click1(object sender, EventArgs e)
    {
        if (TextBox4.Text == TextBox5.Text)
        {
            string str = "Update Candidates set password='" + TextBox5.Text + "' where email='" + TextBox1.Text + "' ";
            SqlCommand cmd1 = new SqlCommand(str, con);
            con.Open();
            cmd1.ExecuteNonQuery();
            con.Close();
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Successfully Updated')", true);
        }
        else
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('New Password and conform password should be same!')", true);
        }
    }
}
