﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Admin_membership_validity : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (!this.IsPostBack)
        //{
        //    this.BindStatus();
        //}
        //GridView1.DataBind();
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
        //SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-03AQA86\SQLEXPRESS;Initial Catalog=Fit;Integrated Security=true");
        //string str = "select * from [dbo].[Candidates] where Name='" + TextBox1.Text + "'";
        //SqlCommand cmd = new SqlCommand(str, con);
        //con.Open();
        //SqlDataAdapter da = new SqlDataAdapter(cmd);
        //DataTable dt = new DataTable();
        //da.Fill(dt);
        //GridView1.DataSource = dt;
        ////GridView1.DataBind();
        //con.Close();
    }
    //private void BindStatus()
    //{
    //    SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-03AQA86\SQLEXPRESS;Initial Catalog=Fit;Integrated Security=true");
    //    SqlCommand cmd = new SqlCommand("select Name from Candidates");
    //    con.Open();
    //    GridView1.DataSource = cmd.ExecuteNonQuery();
    //    GridView1.DataBind();
    //    con.Close();
    //}
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DateTime Date = Convert.ToDateTime(e.Row.Cells[3].Text);
            e.Row.Cells[3].Text = Date.ToString("dd-MMMM-yyyy");
            DateTime Date1 = Convert.ToDateTime(e.Row.Cells[4].Text);
            e.Row.Cells[4].Text = Date1.ToString("dd-MMMM-yyyy");
        }

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string dtimeString = Convert.ToDateTime(e.Row.Cells[4].Text).ToString("dd/MM/yy");

            DateTime dtime = Convert.ToDateTime(dtimeString);

            //string dtimeString1 = Convert.ToDateTime(e.Row.Cells[4].Text).ToString("dd/MM/yy");
            var today = DateTime.Today;
            int result = DateTime.Compare(today, dtime);

            Console.Write(dtime);

            Console.Write(result);

            //DateTime nowtime = Convert.ToDateTime(DateTime.Now.ToString("dd/MM/yy"));
            if (result <= 0)
            {
                //change the column backcolor 
                e.Row.Cells[0].BackColor = System.Drawing.Color.LightGreen;

                //change the row backcolor
                //  e.Row.BackColor = System.Drawing.Color.Yellow;
            }
            else
            {
                e.Row.Cells[0].BackColor = System.Drawing.Color.Red;

                // e.Row.BackColor = System.Drawing.Color.Red;
            }
        }
    }
    protected void GridView2_RowDataBound1(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DateTime Date = Convert.ToDateTime(e.Row.Cells[3].Text);
            e.Row.Cells[3].Text = Date.ToString("dd-MMMM-yyyy");
            DateTime Date1 = Convert.ToDateTime(e.Row.Cells[4].Text);
            e.Row.Cells[4].Text = Date1.ToString("dd-MMMM-yyyy");
        }

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string dtimeString = Convert.ToDateTime(e.Row.Cells[4].Text).ToString("dd/MM/yy");

            DateTime dtime = Convert.ToDateTime(dtimeString);

            //string dtimeString1 = Convert.ToDateTime(e.Row.Cells[4].Text).ToString("dd/MM/yy");
            var today = DateTime.Today;
            int result = DateTime.Compare(today, dtime);

            Console.Write(dtime);

            Console.Write(result);

            //DateTime nowtime = Convert.ToDateTime(DateTime.Now.ToString("dd/MM/yy"));
            if (result <= 0)
            {
                //change the column backcolor 
                e.Row.Cells[0].BackColor = System.Drawing.Color.LightGreen;

                //change the row backcolor
                //  e.Row.BackColor = System.Drawing.Color.Yellow;
            }
            else
            {
                e.Row.Cells[0].BackColor = System.Drawing.Color.Red;

                // e.Row.BackColor = System.Drawing.Color.Red;
            }
        }
    }
}