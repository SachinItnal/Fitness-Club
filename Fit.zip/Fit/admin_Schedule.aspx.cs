﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class admin_Schedule : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //    SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-03AQA86\SQLEXPRESS;Initial Catalog=Fit;Integrated Security=true");
        //    con.Open();
        //    SqlCommand cmd = new SqlCommand("select * from Trainers" , con);
        //    SqlDataAdapter da = new SqlDataAdapter(cmd);
        //    DataSet ds = new DataSet();
        //    da.Fill(ds);
        //    DropDownList1.DataTextField = "T_id";
        //    DropDownList1.DataValueField = "Name";
        //    DropDownList1.DataSource = ds;
        //    DropDownList1.DataBind();
        //    DropDownList1.Items.Insert(0, new ListItem("-Select Trainer-", "0"));

        //    SqlCommand cmd1 = new SqlCommand("select * from Candidates", con);
        //    SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
        //    DataSet ds1 = new DataSet();
        //    da1.Fill(ds1);
        //    DropDownList2.DataTextField = "C_id";
        //    DropDownList2.DataValueField = "Name";
        //    DropDownList2.DataSource = ds1;
        //    DropDownList2.DataBind();
        //    DropDownList2.Items.Insert(0, new ListItem("-Select Member-", "0"));
        //}
        //protected void Button1_Click(object sender, EventArgs e)
        //{
        //    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Schedule Saved SuccessFully')", true);
        //    SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-03AQA86\SQLEXPRESS;Initial Catalog=Fit;Integrated Security=true");
        //    string str = "insert into Schedule values('" + DropDownList1.SelectedItem + "','" + DropDownList2.SelectedItem + "','"+TextBox1.Text+"','"+TextBox2.Text+"','"+TextBox3.Text+"','"+TextBox4.Text+"')";
        //    SqlCommand cmd = new SqlCommand(str, con);
        //    con.Open();
        //    cmd.ExecuteNonQuery();
        //    con.Close();
        //    TextBox1.Text = "";
        //    TextBox2.Text = "";
        //    TextBox3.Text = "";
        //    TextBox4.Text = "";
        //}
        //protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        //{

        //}
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DateTime Date = Convert.ToDateTime(e.Row.Cells[3].Text);
            e.Row.Cells[3].Text = Date.ToString("dd-MMMM-yyyy");
            DateTime Date1 = Convert.ToDateTime(e.Row.Cells[4].Text);
            e.Row.Cells[4].Text = Date1.ToString("dd-MMMM-yyyy");
        }
    }
}