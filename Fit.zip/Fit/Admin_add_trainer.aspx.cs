﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Text;
using System.Net.Mail;
using System.Net;
using System.IO;

public partial class Admin_add_trainer : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Data Saved SuccessFully')", true);
        string utype = "trainer";
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-03AQA86\SQLEXPRESS;Initial Catalog=Fit;Integrated Security=true");
        string gender = " ";
        if (RadioButton1.Checked)
        {
            gender = "Male";
        }
        else if (RadioButton2.Checked)
        {
            gender = "Female";
        }
        DateTime dt = DateTime.Parse(TextBox4.Text);
        FileUpload1.SaveAs(Server.MapPath("~/image/") + Path.GetFileName(FileUpload1.FileName));
        string link = "image/" + Path.GetFileName(FileUpload1.FileName);
        string str = "insert into Trainers values('" + TextBox10.Text + "','" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox9.Text + "','" + TextBox3.Text + "','" + gender + "','" + TextBox4.Text + "','" + link + "','" + TextBox5.Text + "','" + TextBox6.Text + "','" + TextBox7.Text + "','" + TextBox8.Text + "','" + utype + "')";
        //string str1 = "insert into Login values('" + TextBox7.Text + "','" + TextBox8.Text + "','" + utype + "')";
        SqlCommand cmd = new SqlCommand(str, con);
        //SqlCommand cmd1 = new SqlCommand(str1, con);
        con.Open();
        cmd.ExecuteNonQuery();
        //cmd1.ExecuteNonQuery();
        con.Close();
        Response.Redirect("admin_trainer.aspx");

        StringBuilder sb = new StringBuilder();
        sb.AppendLine("You Have Successfully Registered");
        sb.AppendLine("Your Username is :" + TextBox7.Text);
        sb.AppendLine("Your Password is :" + TextBox8.Text);

        SmtpClient sc = new SmtpClient("smtp.gmail.com", 587);
        sc.EnableSsl = true;
        sc.DeliveryMethod = SmtpDeliveryMethod.Network;
        sc.UseDefaultCredentials = false;
        sc.Credentials = new NetworkCredential("sachinitnal8@gmail.com", "ykvrsbqwxftmgpuh");
        MailMessage msg = new MailMessage();
        msg.To.Add(TextBox9.Text);
        msg.From = new MailAddress("Fitness Club<sachinitnal8@gmail.com>");
        msg.Subject = "Fitness Club";
        msg.Body = sb.ToString();
        sc.Send(msg);

        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";
        TextBox6.Text = "";
        TextBox7.Text = "";
        TextBox8.Text = "";
        TextBox9.Text = "";
        TextBox10.Text = "";
    }
}