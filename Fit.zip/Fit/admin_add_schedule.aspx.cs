﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class admin_add_schedule : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-03AQA86\SQLEXPRESS;Initial Catalog=Fit;Integrated Security=true");
    protected void Page_Load(object sender, EventArgs e)
    {
        //GridView1.Visible = true;
        if (!IsPostBack)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from Trainers", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            DropDownList1.DataTextField = "Name";
            DropDownList1.DataValueField = "T_id";
            DropDownList1.DataSource = ds;
            DropDownList1.DataBind();
            DropDownList1.Items.Insert(0, new ListItem("-Select Trainer-", "0"));

            SqlCommand cmd1 = new SqlCommand("select * from Candidates", con);
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            DataSet ds1 = new DataSet();
            da1.Fill(ds1);
            DropDownList2.DataTextField = "Name";
            DropDownList2.DataValueField = "C_id";
            DropDownList2.DataSource = ds1;
            DropDownList2.DataBind();
            DropDownList2.Items.Insert(0, new ListItem("-Select Member-", "0"));
        }

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        TextBox3.Text = (TextBox3.Text + " " + DropDownList3.SelectedItem).ToString();
        TextBox4.Text = (TextBox4.Text + " " + DropDownList4.SelectedItem).ToString();


        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Schedule Saved SuccessFully')", true);
        string str = "insert into workout_duration values('" + DropDownList1.SelectedItem + "','" + DropDownList2.SelectedItem + "','" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "')";
        SqlCommand cmd = new SqlCommand(str, con);
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
        Response.Redirect("admin_Schedule.aspx");
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        //string text = DropDownList1.SelectedValue;
        //con.Open();
        //string st = "select * from Trainers where Name='" + DropDownList1.SelectedValue + "'";
        //SqlCommand cm = new SqlCommand(st, con);
        //SqlDataAdapter da = new SqlDataAdapter(cm);
        //DataTable dt = new DataTable();
        //da.Fill(dt);
        //TextBox5.Text = dt.Rows[1]["Name"].ToString();
        //con.Close();
    }
}