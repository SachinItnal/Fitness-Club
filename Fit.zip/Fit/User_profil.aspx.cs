﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class User_profil : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-03AQA86\SQLEXPRESS;Initial Catalog=Fit;Integrated Security=true");
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        DataList1.DataBind();
            //filldata();
    }
    //private void filldata()
    //{
    //    SqlDataAdapter da = new SqlDataAdapter("select * from Candidates", con);
    //    DataSet ds = new DataSet();
    //    da.Fill(ds);
    //    //DataList1.DataSource = da;
    //    //DataList1.DataBind();
    //}
    protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
    {
        if (e.CommandName == "edit")
        {
            DataList1.EditItemIndex = e.Item.ItemIndex;
            //filldata();
        }
        else if (e.CommandName == "cancel")
        {
            DataList1.EditItemIndex = 1;
            Response.Redirect("User_profil.aspx");
            //filldata();
        }
        else if (e.CommandName == "update")
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Data Saved SuccessFully')", true);
            string Name = ((TextBox)e.Item.FindControl("TextBox1")).Text;
            string Contactnumber = ((TextBox)e.Item.FindControl("TextBox2")).Text;
            string EmailId = ((TextBox)e.Item.FindControl("TextBox3")).Text;
            string Address = ((TextBox)e.Item.FindControl("TextBox4")).Text;
            string DateOfBirth = ((TextBox)e.Item.FindControl("TextBox6")).Text;
            string username = ((TextBox)e.Item.FindControl("TextBox7")).Text;
            SqlCommand cmd = new SqlCommand("update Candidates set Name='" + Name + "',ContactNumber='"+Contactnumber+"',email='"+EmailId+"',address='"+Address+"',dob='"+DateOfBirth+"',username='"+username+"' where C_id='" + Session["C_id"] + "'", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Redirect("User_profil.aspx");
            //filldata();
        }
    }
}