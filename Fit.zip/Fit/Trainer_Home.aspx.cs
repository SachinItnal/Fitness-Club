﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Pages_Trainer_Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-03AQA86\SQLEXPRESS;Initial Catalog=Fit;Integrated Security=true");
        //string str1 = "select T_id from Schedule where C_id='" + Session["C_id"] + "'";
        ////string str = "SELECT t.Name, t.Photo, s.Time_from, s.Time_to from Trainers AS t INNER JOIN Schedule AS s ON t.T_id=s.T_id";
        //SqlCommand cmd = new SqlCommand(str1, con);
        //SqlDataAdapter da = new SqlDataAdapter(cmd);
        //DataTable dt = new DataTable();
        //da.Fill(dt);
        //if (dt.Rows.Count >= 1)
        //{
        //    string tid = dt.Rows[0]["T_id"].ToString();
        //    string str2 = "select Name,Photo from Trainers where T_id='" + tid + "'";
        //    SqlCommand cmd1 = new SqlCommand(str2, con);
        //    SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
        //    DataTable dt1 = new DataTable();
        //    da1.Fill(dt1);
        //    if (dt.Rows.Count >= 1)
        //    {
        //        GridView3.DataSource = dt1;
        //        GridView3.DataBind();
        //    }
        //}
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string Status;
        string sdate = DateTime.Now.ToString();
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-03AQA86\SQLEXPRESS;Initial Catalog=Fit;Integrated Security=true");
        try
        {
            CheckBox CheckBox;
            foreach (GridViewRow row in GridView3.Rows)
            {
                //Status = "1";                                               
                CheckBox = (CheckBox)row.FindControl("CheckBox1");
                if (CheckBox.Checked)
                {
                    Status = "Present";
                }
                else
                {
                    Status = "Absent";

                }
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into Status values('" + row.Cells[0].Text + "','" + row.Cells[1].Text + "',  '" + Status + "','" + sdate + "')";
                cmd.ExecuteNonQuery();
                con.Close();
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Record Added Successfully!')", true);
            }
        }
        catch (Exception Ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Plz Sorry')", true);
        }
        GridView2.DataBind();
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DateTime Date = Convert.ToDateTime(e.Row.Cells[3].Text);
            e.Row.Cells[3].Text = Date.ToString("dd-MMMM-yyyy");
            DateTime Date1 = Convert.ToDateTime(e.Row.Cells[4].Text);
            e.Row.Cells[4].Text = Date1.ToString("dd-MMMM-yyyy");
        }
    }
    protected void GridView2_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DateTime Date = Convert.ToDateTime(e.Row.Cells[2].Text);
            e.Row.Cells[2].Text = Date.ToString("dd-MMMM-yyyy");
        }
    }
    protected void GridView3_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DateTime Date = Convert.ToDateTime(e.Row.Cells[3].Text);
            e.Row.Cells[3].Text = Date.ToString("dd-MMMM-yyyy");
            DateTime Date1 = Convert.ToDateTime(e.Row.Cells[2].Text);
            e.Row.Cells[2].Text = Date1.ToString("dd-MMMM-yyyy");
        }
    }
}