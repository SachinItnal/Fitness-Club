﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class User_Plan : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DateTime Date = Convert.ToDateTime(e.Row.Cells[3].Text);
            e.Row.Cells[3].Text = Date.ToString("dd-MMMM-yyyy");
            DateTime Date1 = Convert.ToDateTime(e.Row.Cells[2].Text);
            e.Row.Cells[2].Text = Date1.ToString("dd-MMMM-yyyy");
        }
    }
    protected void GridView2_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DateTime Date = Convert.ToDateTime(e.Row.Cells[3].Text);
            e.Row.Cells[3].Text = Date.ToString("dd-MMMM-yyyy");
            DateTime Date1 = Convert.ToDateTime(e.Row.Cells[2].Text);
            e.Row.Cells[2].Text = Date1.ToString("dd-MMMM-yyyy");
        }
    }
}