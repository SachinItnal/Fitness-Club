﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Change_password : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-03AQA86\SQLEXPRESS;Initial Catalog=Fit;Integrated Security=true");
        string str = "select * from Candidates where password='" + TextBox1.Text + "'";
        con.Open();
        SqlCommand cmd = new SqlCommand(str, con);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.HasRows==true)
        {
            dr.Read();
            if (TextBox2.Text == TextBox3.Text)
            { 
                cmd =new SqlCommand( "Update Candidates set password='" + TextBox3.Text + "' where password='" + TextBox1.Text + "'");
                cmd.ExecuteNonQuery();
                con.Close();
                Label1.Text = "Successfully Updated";
            }
            else
            {
                Label1.Text = "New Password and conform password should be same!";
            }
        }
        else
        {
            Label1.Text = "Please check your old password";
        }
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
    }
}